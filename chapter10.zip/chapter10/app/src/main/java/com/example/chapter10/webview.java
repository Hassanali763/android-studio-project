package com.example.chapter10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        WebView webView = findViewById(R.id.webview1);
        webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url){
                // do your handling codes here, which url is the requested url
                // probably you need to open that url rather than redirect:
                view.loadUrl(url);
                return false; // then it is not handled by default action
            }
        });
        webView.getSettings().setJavaScriptEnabled(true);
        Bundle b= getIntent().getExtras();
        switch(b.getInt("website")){
            case 0:{
                webView.loadUrl("https://facebook.com");
                break;
            }
            case 1:{
                webView.loadUrl("https://www.google.com/maps/@31.8746777,74.4877817,10.5z");
                break;
            }
        }
    }
}